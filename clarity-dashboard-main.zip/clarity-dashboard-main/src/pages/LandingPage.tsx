import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CheckCircle2, ChevronDown, ArrowRight, Star, Users, FileText,
  DollarSign, BarChart3, Shield, Zap, Clock, Menu, X,
} from "lucide-react";

// ── HERO DATA ─────────────────────────────────────────────────────────────
const FEATURES = [
  {
    icon: Users,
    title: "Recrutamento Inteligente",
    desc: "Crie processos seletivos, aplique provas online e gerencie candidatos de forma centralizada. Chega de planilhas!",
    color: "bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400",
  },
  {
    icon: FileText,
    title: "Contratos Digitais",
    desc: "Formalize contratações em minutos com nosso fluxo de assinatura digital integrado. 100% online e com validade jurídica.",
    color: "bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400",
  },
  {
    icon: DollarSign,
    title: "Financeiro Automatizado",
    desc: "Gere faturas, controle pagamentos e calcule a folha de pagamento sem esforço. Visão clara da saúde financeira.",
    color: "bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400",
  },
  {
    icon: BarChart3,
    title: "Relatórios e Conformidade",
    desc: "Mantenha-se em dia com a legislação. Gere relatórios de frequência, atividades e acompanhamento em poucos cliques.",
    color: "bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400",
  },
];

const STEPS = [
  { num: "01", title: "Cadastre sua empresa", desc: "Crie sua conta em minutos e configure as informações da sua empresa e equipe." },
  { num: "02", title: "Configure os processos", desc: "Adicione vagas, candidatos, modelos de contrato e parametrize os alertas." },
  { num: "03", title: "Gerencie em tempo real", desc: "Acompanhe contratos, frequências, folha e relatórios em um único painel." },
];

const TESTIMONIALS = [
  {
    quote: "O LideraRH transformou nossa gestão de estagiários. Ganhamos agilidade e segurança em todos os processos.",
    name: "Ana Rodrigues",
    role: "Gerente de RH",
    company: "TechCorp Brasil",
    initials: "AR",
    color: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  },
  {
    quote: "A integração de contratos digitais economizou horas de trabalho semanal para nossa equipe de RH.",
    name: "Carlos Mendes",
    role: "Diretor de Operações",
    company: "LogBrasil S.A.",
    initials: "CM",
    color: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  },
  {
    quote: "Dashboard completo e relatórios precisos. Finalmente tenho visibilidade total do nosso programa de aprendizes.",
    name: "Mariana Costa",
    role: "Analista RH Sênior",
    company: "FinGroup LTDA",
    initials: "MC",
    color: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
  },
];

const PLANS = [
  {
    name: "Básico",
    price_monthly: 299,
    price_annual: 239,
    desc: "Para empresas que estão começando",
    features: ["Até 50 contratos ativos", "Módulos de Cadastro e Recrutamento", "Contratos digitais básicos", "Relatórios padrão", "Suporte por e-mail"],
    highlight: false,
  },
  {
    name: "Profissional",
    price_monthly: 699,
    price_annual: 559,
    desc: "Para gestores que precisam de mais",
    features: ["Até 200 contratos ativos", "Todos os módulos inclusos", "Jovem Aprendiz completo", "Relatórios avançados", "NFS-e integrado", "Suporte prioritário"],
    highlight: true,
  },
  {
    name: "Enterprise",
    price_monthly: null,
    price_annual: null,
    desc: "Para grandes operações",
    features: ["Contratos ilimitados", "Todos os módulos + API", "CRM e módulos avançados", "Relatórios customizados", "Integração com ERP", "Gerente de conta dedicado"],
    highlight: false,
  },
];

const FAQS = [
  { q: "O LideraRH é adequado para qualquer tamanho de empresa?", a: "Sim. Temos planos desde pequenas empresas com 10 estagiários até grandes corporações com centenas de jovens aprendizes. Cada plano é dimensionado para o seu volume." },
  { q: "Posso migrar meus dados de outros sistemas?", a: "Com certeza. Nossa ferramenta de Importações aceita arquivos CSV e Excel. Nossa equipe de suporte também pode auxiliar na migração de sistemas legados." },
  { q: "A assinatura digital tem validade jurídica?", a: "Sim. Utilizamos padrão ICP-Brasil e certificados qualificados, garantindo validade jurídica plena conforme a MP 2.200-2/2001 e a Lei 14.063/2020." },
  { q: "Como funciona o período de teste gratuito?", a: "Oferecemos 14 dias de teste gratuito com acesso completo ao plano Profissional, sem necessidade de cartão de crédito. Cancele quando quiser." },
  { q: "Preciso de conhecimento técnico para usar?", a: "Não. O LideraRH foi projetado para ser usado por profissionais de RH, sem necessidade de conhecimento técnico. Interface intuitiva e suporte completo." },
];

// ── COMPONENT ─────────────────────────────────────────────────────────────
export default function LandingPage() {
  const navigate = useNavigate();
  const [annual, setAnnual] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [form, setForm] = useState({ nome: "", email: "", telefone: "", porte: "" });

  const handleDemo = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Solicitação recebida! ${form.nome}, entraremos em contato em até 24h.`);
    setForm({ nome: "", email: "", telefone: "", porte: "" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">

      {/* ── HEADER ── */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-black text-sm">L</span>
            </div>
            <span className="font-bold text-lg text-foreground">LideraRH</span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8 text-sm">
            {["Funcionalidades", "Planos", "Depoimentos", "FAQ"].map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} className="text-muted-foreground hover:text-foreground transition-colors">
                {item}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <button onClick={() => navigate("/login")} className="text-sm font-medium text-foreground hover:text-primary transition-colors px-4 py-2">
              Entrar
            </button>
            <button onClick={() => navigate("/signup")} className="text-sm font-medium bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors">
              Começar grátis
            </button>
          </div>

          {/* Mobile menu */}
          <button className="md:hidden p-2 rounded-lg hover:bg-muted" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden border-t border-border bg-background px-6 py-4 space-y-3">
            {["Funcionalidades", "Planos", "Depoimentos", "FAQ"].map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setMenuOpen(false)} className="block text-sm text-muted-foreground hover:text-foreground py-1">
                {item}
              </a>
            ))}
            <button onClick={() => navigate("/login")} className="block w-full text-left text-sm font-medium py-2 text-foreground">Entrar</button>
            <button onClick={() => navigate("/signup")} className="block w-full text-center bg-primary text-primary-foreground text-sm font-medium py-2 rounded-lg">
              Começar grátis
            </button>
          </div>
        )}
      </header>

      {/* ── HERO ── */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-24 text-center">
        <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-xs font-semibold px-3 py-1.5 rounded-full mb-6 border border-primary/20">
          <Zap className="h-3 w-3" />
          Plataforma #1 para gestão de estágios e aprendizes
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-foreground max-w-3xl mx-auto leading-tight mb-6">
          A plataforma{" "}
          <span className="text-primary">completa</span>{" "}
          para gestão de talentos
        </h1>

        <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
          Do recrutamento ao financeiro, centralize toda a gestão de estágios e jovens aprendizes em um único lugar. Automatize, simplifique e cresça.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-12">
          <button
            onClick={() => navigate("/signup")}
            className="inline-flex items-center gap-2 bg-primary text-primary-foreground text-base font-semibold px-8 py-3.5 rounded-xl hover:bg-primary/90 transition-all hover:shadow-lg hover:-translate-y-0.5"
          >
            Agendar Demonstração Gratuita <ArrowRight className="h-4 w-4" />
          </button>
          <button className="inline-flex items-center gap-2 text-base font-medium text-foreground px-6 py-3.5 rounded-xl border border-border hover:bg-muted transition-colors">
            Ver como funciona
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto">
          {[
            { val: "500+", label: "Empresas parceiras" },
            { val: "12k+", label: "Contratos gerenciados" },
            { val: "50k+", label: "Candidatos cadastrados" },
            { val: "80+", label: "Módulos e funcionalidades" },
          ].map((s) => (
            <div key={s.label} className="p-4 rounded-xl bg-card border border-border">
              <p className="text-2xl font-black text-primary">{s.val}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── LOGOS ── */}
      <section className="border-y border-border bg-muted/30 py-8">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-6">Confiam na nossa expertise</p>
          <div className="flex flex-wrap items-center justify-center gap-8">
            {["TechCorp", "LogBrasil", "FinGroup", "HealthMed", "InnovaTec", "MegaCorp"].map((name) => (
              <span key={name} className="text-muted-foreground/50 font-bold text-sm tracking-widest uppercase">{name}</span>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="funcionalidades" className="max-w-6xl mx-auto px-6 py-24">
        <div className="text-center mb-14">
          <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4">Tudo que você precisa em um único lugar</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">Módulos completos que cobrem todo o ciclo de vida dos seus programas de estágio e jovem aprendiz.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES.map((f) => (
            <div key={f.title} className="p-6 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-lg transition-all duration-200 group">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${f.color}`}>
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="font-bold text-foreground mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── STEPS ── */}
      <section className="bg-muted/30 border-y border-border py-24">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4">Comece em 3 passos simples</h2>
          </div>
          <div className="grid sm:grid-cols-3 gap-8">
            {STEPS.map((step, i) => (
              <div key={step.num} className="relative text-center">
                {i < STEPS.length - 1 && (
                  <div className="hidden sm:block absolute top-8 left-1/2 w-full h-px bg-border" />
                )}
                <div className="relative inline-flex w-16 h-16 rounded-2xl bg-primary text-primary-foreground items-center justify-center font-black text-xl mb-4 shadow-lg">
                  {step.num}
                </div>
                <h3 className="font-bold text-foreground mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section id="depoimentos" className="max-w-6xl mx-auto px-6 py-24">
        <div className="text-center mb-14">
          <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4">O que nossos clientes dizem</h2>
        </div>
        <div className="grid sm:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="p-6 rounded-2xl bg-card border border-border">
              <div className="flex gap-1 mb-4">
                {Array(5).fill(0).map((_, i) => <Star key={i} className="h-4 w-4 fill-amber-400 text-amber-400" />)}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed italic mb-6">"{t.quote}"</p>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${t.color}`}>
                  {t.initials}
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role} · {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── PLANS ── */}
      <section id="planos" className="bg-muted/30 border-y border-border py-24">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4">Planos e Preços</h2>
            <p className="text-muted-foreground mb-6">Sem surpresas. Preço fixo, sem taxas por uso.</p>
            {/* Toggle mensal/anual */}
            <div className="inline-flex items-center gap-3 p-1 bg-card border border-border rounded-xl">
              <button onClick={() => setAnnual(false)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${!annual ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                Mensal
              </button>
              <button onClick={() => setAnnual(true)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${annual ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                Anual
                <span className="text-xs bg-emerald-500 text-white px-1.5 py-0.5 rounded-full">-20%</span>
              </button>
            </div>
          </div>

          <div className="grid sm:grid-cols-3 gap-6">
            {PLANS.map((plan) => (
              <div key={plan.name} className={`p-6 rounded-2xl bg-card transition-all ${plan.highlight ? "border-2 border-primary shadow-xl scale-[1.02]" : "border border-border"}`}>
                {plan.highlight && (
                  <div className="inline-flex items-center gap-1 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full mb-4">
                    <Star className="h-3 w-3 fill-current" /> Mais popular
                  </div>
                )}
                <h3 className="text-lg font-black text-foreground mb-1">{plan.name}</h3>
                <p className="text-xs text-muted-foreground mb-4">{plan.desc}</p>
                <div className="mb-6">
                  {plan.price_monthly ? (
                    <>
                      <span className="text-3xl font-black text-foreground">
                        R$ {annual ? plan.price_annual : plan.price_monthly}
                      </span>
                      <span className="text-sm text-muted-foreground">/mês</span>
                      {annual && <p className="text-xs text-emerald-600 font-medium mt-0.5">Cobrado anualmente</p>}
                    </>
                  ) : (
                    <span className="text-2xl font-black text-foreground">Sob consulta</span>
                  )}
                </div>
                <ul className="space-y-2.5 mb-6">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => navigate("/signup")}
                  className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-colors ${plan.highlight ? "bg-primary text-primary-foreground hover:bg-primary/90" : "border border-border hover:bg-muted text-foreground"}`}
                >
                  {plan.price_monthly ? "Quero este plano" : "Falar com um especialista"}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section id="faq" className="max-w-3xl mx-auto px-6 py-24">
        <div className="text-center mb-14">
          <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4">Perguntas frequentes</h2>
        </div>
        <div className="space-y-3">
          {FAQS.map((faq, i) => (
            <div key={i} className="rounded-xl bg-card border border-border overflow-hidden">
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between p-5 text-left text-sm font-semibold text-foreground hover:bg-muted/30 transition-colors"
              >
                {faq.q}
                <ChevronDown className={`h-4 w-4 text-muted-foreground shrink-0 ml-3 transition-transform ${openFaq === i ? "rotate-180" : ""}`} />
              </button>
              {openFaq === i && (
                <div className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed border-t border-border pt-4">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA FINAL ── */}
      <section className="max-w-6xl mx-auto px-6 pb-24">
        <div className="rounded-2xl bg-primary p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-white translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-white -translate-x-1/3 translate-y-1/3" />
          </div>
          <div className="relative z-10 max-w-2xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-black text-primary-foreground mb-3">
              Pronto para revolucionar sua gestão de talentos?
            </h2>
            <p className="text-primary-foreground/80 mb-8">
              Fale com um dos nossos especialistas. Demonstração gratuita, sem compromisso.
            </p>
            <form onSubmit={handleDemo} className="grid sm:grid-cols-2 gap-3 mb-4">
              <input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} placeholder="Seu nome" required
                className="h-11 px-4 rounded-xl bg-white/15 text-white placeholder:text-white/60 border border-white/20 text-sm focus:outline-none focus:border-white/50 backdrop-blur-sm" />
              <input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="Email corporativo" type="email" required
                className="h-11 px-4 rounded-xl bg-white/15 text-white placeholder:text-white/60 border border-white/20 text-sm focus:outline-none focus:border-white/50" />
              <input value={form.telefone} onChange={e => setForm({ ...form, telefone: e.target.value })} placeholder="Telefone" required
                className="h-11 px-4 rounded-xl bg-white/15 text-white placeholder:text-white/60 border border-white/20 text-sm focus:outline-none focus:border-white/50" />
              <select value={form.porte} onChange={e => setForm({ ...form, porte: e.target.value })} required
                className="h-11 px-4 rounded-xl bg-white/15 text-white border border-white/20 text-sm focus:outline-none focus:border-white/50 appearance-none">
                <option value="" disabled className="text-gray-800">Número de estagiários/aprendizes</option>
                <option value="1-10" className="text-gray-800">1 a 10</option>
                <option value="11-50" className="text-gray-800">11 a 50</option>
                <option value="51-200" className="text-gray-800">51 a 200</option>
                <option value="200+" className="text-gray-800">Mais de 200</option>
              </select>
            </form>
            <button type="submit" onClick={handleDemo}
              className="inline-flex items-center gap-2 bg-white text-primary font-bold text-sm px-8 py-3 rounded-xl hover:bg-white/90 transition-colors shadow-lg">
              Agendar minha Demonstração <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-border bg-muted/20">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="grid sm:grid-cols-4 gap-8 mb-10">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
                  <span className="text-primary-foreground font-black text-xs">L</span>
                </div>
                <span className="font-bold text-foreground">LideraRH</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">Simplificando a gestão de talentos para empresas brasileiras.</p>
            </div>
            {[
              { title: "Produto", links: ["Funcionalidades", "Planos", "Segurança", "Integrações"] },
              { title: "Empresa", links: ["Sobre nós", "Blog", "Carreiras", "Contato"] },
              { title: "Legal", links: ["Termos de Serviço", "Política de Privacidade", "Cookies", "Conformidade"] },
            ].map((col) => (
              <div key={col.title}>
                <p className="text-xs font-semibold text-foreground uppercase tracking-wider mb-3">{col.title}</p>
                <ul className="space-y-2">
                  {col.links.map((link) => (
                    <li key={link}><a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">{link}</a></li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} LideraRH. Todos os direitos reservados.</p>
            <div className="flex items-center gap-4">
              {["LinkedIn", "Instagram", "WhatsApp"].map((social) => (
                <a key={social} href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">{social}</a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
