import { useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { DataTable, Column, FilterConfig, ActionConfig } from "@/components/DataTable";
import { FormModal } from "@/components/FormModal";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RichTextEditor } from "@/components/RichTextEditor";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Save, Plus, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

// ── shared ──────────────────────────────────────────────────────────────
const statusBadge = (v: boolean | string) => {
  const active = v === true || v === "Ativo" || v === "Sim";
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold",
      active ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
              : "bg-muted text-muted-foreground")}>
      {active ? "Ativo" : "Inativo"}
    </span>
  );
};

function SimpleCrudPage({
  breadcrumb, title, subtitle, columns, filters, data: init, fields, modalTitle,
}: {
  breadcrumb: string; title: string; subtitle?: string;
  columns: Column[]; filters?: FilterConfig[];
  data: any[]; fields: React.ReactNode; modalTitle?: string;
}) {
  const [data, setData] = useState(init);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [formData, setFormData] = useState<any>({});

  const actions: ActionConfig[] = [
    {
      label: "Editar", onClick: (r) => {
        setEditing(r); setFormData(r); setModal(true);
      }
    },
    {
      label: "Excluir", variant: "destructive",
      onClick: (r) => setConfirm(r)
    },
  ];

  const handleSave = () => {
    if (editing) {
      setData(data.map((d) => d.id === editing.id ? { ...d, ...formData } : d));
      toast.success("Registro atualizado!");
    } else {
      setData([...data, { id: String(Date.now()), ...formData }]);
      toast.success("Registro criado!");
    }
    setModal(false); setEditing(null); setFormData({});
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: breadcrumb }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">{title}</h1>
            {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
          </div>
          <button
            onClick={() => { setEditing(null); setFormData({}); setModal(true); }}
            className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"
          >
            <Plus className="h-4 w-4" /> Novo Registro
          </button>
        </div>
        <DataTable columns={columns} data={data} filters={filters} actions={actions} />
      </div>

      <FormModal
        open={modal} onClose={() => { setModal(false); setEditing(null); setFormData({}); }}
        title={(editing ? "Editar " : "Novo ") + (modalTitle || title)}
        onSave={handleSave}
      >
        {typeof fields === "function" ? fields(formData, setFormData) : fields}
      </FormModal>

      <ConfirmDialog
        open={!!confirm} onClose={() => setConfirm(null)}
        onConfirm={() => { setData(data.filter((d) => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }}
        title="Confirmar exclusão" description="Deseja excluir este registro? Esta ação não pode ser desfeita."
      />
    </DashboardLayout>
  );
}

// ── 1. IDIOMAS ───────────────────────────────────────────────────────────
const idiomasData = [
  { id: "1", nome: "Português (Brasil)", codigo: "pt-BR", ativo: true },
  { id: "2", nome: "English", codigo: "en-US", ativo: false },
  { id: "3", nome: "Español", codigo: "es-ES", ativo: false },
];

export function IdiomasPage() {
  const [data, setData] = useState(idiomasData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ nome: "", codigo: "", ativo: true });

  const columns: Column[] = [
    { key: "nome", label: "Nome", sortable: true },
    { key: "codigo", label: "Código" },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const filters: FilterConfig[] = [{ key: "nome", label: "Nome", type: "text" }];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ nome: r.nome, codigo: r.codigo, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];

  const save = () => {
    if (!form.nome || !form.codigo) { toast.error("Preencha nome e código."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Idioma atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Idioma criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Idiomas" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Idiomas</h1><p className="text-sm text-muted-foreground">{data.length} idiomas cadastrados.</p></div>
          <button onClick={() => { setEditing(null); setForm({ nome: "", codigo: "", ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Novo Idioma</button>
        </div>
        <DataTable columns={columns} data={data} filters={filters} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Idioma" : "Novo Idioma"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Nome *</Label><Input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} placeholder="Português (Brasil)" /></div>
          <div><Label>Código *</Label><Input value={form.codigo} onChange={e => setForm({ ...form, codigo: e.target.value })} placeholder="pt-BR" /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir Idioma" description="Deseja excluir este idioma?" />
    </DashboardLayout>
  );
}

// ── 2. GRAU DE INSTRUÇÃO ─────────────────────────────────────────────────
const grausData = [
  { id: "1", descricao: "Ensino Médio", ordem: 1, ativo: true },
  { id: "2", descricao: "Técnico", ordem: 2, ativo: true },
  { id: "3", descricao: "Superior Incompleto", ordem: 3, ativo: true },
  { id: "4", descricao: "Superior Completo", ordem: 4, ativo: true },
  { id: "5", descricao: "Pós-Graduação", ordem: 5, ativo: true },
  { id: "6", descricao: "Mestrado", ordem: 6, ativo: true },
  { id: "7", descricao: "Doutorado", ordem: 7, ativo: false },
];

export function GrauInstrucaoPage() {
  const [data, setData] = useState(grausData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ descricao: "", ordem: 1, ativo: true });

  const columns: Column[] = [
    { key: "ordem", label: "Ordem" },
    { key: "descricao", label: "Descrição", sortable: true },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ descricao: r.descricao, ordem: r.ordem, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];

  const save = () => {
    if (!form.descricao) { toast.error("Preencha a descrição."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Grau de Instrução" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Grau de Instrução</h1><p className="text-sm text-muted-foreground">{data.length} graus cadastrados.</p></div>
          <button onClick={() => { setEditing(null); setForm({ descricao: "", ordem: data.length + 1, ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Novo</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Grau" : "Novo Grau"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Descrição *</Label><Input value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} /></div>
          <div><Label>Ordem de Exibição</Label><Input type="number" value={form.ordem} onChange={e => setForm({ ...form, ordem: Number(e.target.value) })} /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir Grau de Instrução" description="Deseja excluir este registro?" />
    </DashboardLayout>
  );
}

// ── 3. NÍVEL DE ESTÁGIO ──────────────────────────────────────────────────
const niveisData = [
  { id: "1", descricao: "Ensino Médio", ordem: 1, ativo: true },
  { id: "2", descricao: "Técnico", ordem: 2, ativo: true },
  { id: "3", descricao: "Superior", ordem: 3, ativo: true },
  { id: "4", descricao: "Pós-Graduação", ordem: 4, ativo: true },
];

export function NivelEstagioPage() {
  const [data, setData] = useState(niveisData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ descricao: "", ordem: 1, ativo: true });

  const columns: Column[] = [
    { key: "ordem", label: "Ordem" },
    { key: "descricao", label: "Descrição", sortable: true },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ descricao: r.descricao, ordem: r.ordem, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.descricao) { toast.error("Preencha a descrição."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Nível de Estágio" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Nível de Estágio</h1><p className="text-sm text-muted-foreground">{data.length} níveis cadastrados.</p></div>
          <button onClick={() => { setEditing(null); setForm({ descricao: "", ordem: data.length + 1, ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Novo</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Nível" : "Novo Nível"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Descrição *</Label><Input value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} /></div>
          <div><Label>Ordem de Exibição</Label><Input type="number" value={form.ordem} onChange={e => setForm({ ...form, ordem: Number(e.target.value) })} /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir Nível" description="Deseja excluir este nível?" />
    </DashboardLayout>
  );
}

// ── 4. MOTIVOS DE ENCERRAMENTO ───────────────────────────────────────────
const motivosEncerrData = [
  { id: "1", descricao: "Conclusão do período", ativo: true },
  { id: "2", descricao: "Desistência do estagiário", ativo: true },
  { id: "3", descricao: "Desempenho insatisfatório", ativo: true },
  { id: "4", descricao: "Pedido da empresa", ativo: true },
  { id: "5", descricao: "Formatura / Conclusão do curso", ativo: true },
  { id: "6", descricao: "Contratação CLT", ativo: true },
  { id: "7", descricao: "Outro", ativo: true },
];

export function MotivosEncerramentoPage() {
  const [data, setData] = useState(motivosEncerrData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ descricao: "", ativo: true });

  const columns: Column[] = [
    { key: "descricao", label: "Descrição", sortable: true },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ descricao: r.descricao, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.descricao) { toast.error("Preencha a descrição."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Motivos de Encerramento" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Motivos de Encerramento de Contrato</h1><p className="text-sm text-muted-foreground">{data.length} motivos cadastrados.</p></div>
          <button onClick={() => { setEditing(null); setForm({ descricao: "", ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Novo</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Motivo" : "Novo Motivo"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Descrição *</Label><Input value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir Motivo" description="Deseja excluir este motivo?" />
    </DashboardLayout>
  );
}

// ── 5. SETORES DE VAGA ───────────────────────────────────────────────────
const setoresData = [
  { id: "1", nome: "Administrativo", ativo: true },
  { id: "2", nome: "Comercial", ativo: true },
  { id: "3", nome: "Financeiro", ativo: true },
  { id: "4", nome: "RH", ativo: true },
  { id: "5", nome: "Tecnologia da Informação", ativo: true },
  { id: "6", nome: "Marketing", ativo: true },
  { id: "7", nome: "Jurídico", ativo: false },
  { id: "8", nome: "Engenharia", ativo: true },
];

export function SetoresVagaPage() {
  const [data, setData] = useState(setoresData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ nome: "", ativo: true });

  const columns: Column[] = [
    { key: "nome", label: "Nome", sortable: true },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ nome: r.nome, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.nome) { toast.error("Preencha o nome."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Setor atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Setor criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Setores de Vaga" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Setores de Vaga</h1><p className="text-sm text-muted-foreground">{data.length} setores cadastrados.</p></div>
          <button onClick={() => { setEditing(null); setForm({ nome: "", ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Novo Setor</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Setor" : "Novo Setor"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Nome *</Label><Input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir Setor" description="Deseja excluir este setor?" />
    </DashboardLayout>
  );
}

// ── 6. TAGS DO SISTEMA ───────────────────────────────────────────────────
const tagsData = [
  { id: "1", nome: "Urgente", cor: "#ef4444" },
  { id: "2", nome: "Novo", cor: "#22c55e" },
  { id: "3", nome: "Tech", cor: "#3b82f6" },
  { id: "4", nome: "Estágio", cor: "#8b5cf6" },
  { id: "5", nome: "Aprendiz", cor: "#f59e0b" },
];

export function TagsSistemaPage() {
  const [data, setData] = useState(tagsData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ nome: "", cor: "#6b7280" });

  const columns: Column[] = [
    {
      key: "nome", label: "Tag", render: (_, row) => (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold text-white" style={{ backgroundColor: row.cor }}>
          {row.nome}
        </span>
      )
    },
    { key: "cor", label: "Cor", render: (v) => <span className="font-mono text-xs">{v}</span> },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ nome: r.nome, cor: r.cor }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.nome) { toast.error("Preencha o nome."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Tag atualizada!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Tag criada!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Tags do Sistema" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Tags do Sistema</h1>
            <p className="text-sm text-muted-foreground">{data.length} tags cadastradas.</p>
            <div className="flex flex-wrap gap-2 mt-2">
              {data.map(t => (
                <span key={t.id} className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold text-white" style={{ backgroundColor: t.cor }}>{t.nome}</span>
              ))}
            </div>
          </div>
          <button onClick={() => { setEditing(null); setForm({ nome: "", cor: "#6b7280" }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Nova Tag</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Tag" : "Nova Tag"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Nome *</Label><Input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} /></div>
          <div>
            <Label>Cor</Label>
            <div className="flex items-center gap-3 mt-1.5">
              <input type="color" value={form.cor} onChange={e => setForm({ ...form, cor: e.target.value })} className="h-10 w-10 rounded-lg border border-border cursor-pointer" />
              <Input value={form.cor} onChange={e => setForm({ ...form, cor: e.target.value })} placeholder="#6b7280" className="flex-1" />
              <span className="inline-block w-8 h-8 rounded-full" style={{ backgroundColor: form.cor }} />
            </div>
          </div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Tag excluída."); setConfirm(null); }} title="Excluir Tag" description="Deseja excluir esta tag?" />
    </DashboardLayout>
  );
}

// ── 7. UNIDADES DE NEGÓCIO ───────────────────────────────────────────────
const unidadesData = [
  { id: "1", nome: "Sede Manaus", cnpj: "12.345.678/0001-00", responsavel: "Admin", ativo: true },
  { id: "2", nome: "Filial Belém", cnpj: "12.345.678/0002-81", responsavel: "Gerente Belém", ativo: true },
];

export function UnidadesNegocioPage() {
  const [data, setData] = useState(unidadesData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ nome: "", cnpj: "", endereco: "", telefone: "", email: "", responsavel: "" });

  const columns: Column[] = [
    { key: "nome", label: "Unidade", sortable: true },
    { key: "cnpj", label: "CNPJ" },
    { key: "responsavel", label: "Responsável" },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const filters: FilterConfig[] = [
    { key: "nome", label: "Nome", type: "text" },
    { key: "cnpj", label: "CNPJ", type: "text" },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ nome: r.nome, cnpj: r.cnpj, endereco: r.endereco || "", telefone: r.telefone || "", email: r.email || "", responsavel: r.responsavel }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.nome) { toast.error("Preencha o nome."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Unidade atualizada!"); }
    else { setData([...data, { id: String(Date.now()), ...form, ativo: true }]); toast.success("Unidade criada!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Unidades de Negócio" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Unidades de Negócio</h1><p className="text-sm text-muted-foreground">{data.length} unidades cadastradas.</p></div>
          <button onClick={() => { setEditing(null); setForm({ nome: "", cnpj: "", endereco: "", telefone: "", email: "", responsavel: "" }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Nova Unidade</button>
        </div>
        <DataTable columns={columns} data={data} filters={filters} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Unidade" : "Nova Unidade"} onSave={save} wide>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><Label>Nome *</Label><Input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} /></div>
          <div><Label>CNPJ</Label><Input value={form.cnpj} onChange={e => setForm({ ...form, cnpj: e.target.value })} placeholder="00.000.000/0001-00" /></div>
          <div><Label>Responsável</Label><Input value={form.responsavel} onChange={e => setForm({ ...form, responsavel: e.target.value })} /></div>
          <div><Label>Telefone</Label><Input value={form.telefone} onChange={e => setForm({ ...form, telefone: e.target.value })} /></div>
          <div><Label>Email</Label><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
          <div className="col-span-2"><Label>Endereço</Label><Input value={form.endereco} onChange={e => setForm({ ...form, endereco: e.target.value })} /></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluída."); setConfirm(null); }} title="Excluir Unidade" description="Deseja excluir esta unidade?" />
    </DashboardLayout>
  );
}

// ── 8. FAQ ───────────────────────────────────────────────────────────────
const faqData = [
  { id: "1", pergunta: "Como cadastrar uma empresa parceira?", categoria: "Cadastros", ativo: true },
  { id: "2", pergunta: "Como gerar a folha de pagamento?", categoria: "Financeiro", ativo: true },
  { id: "3", pergunta: "Como emitir um contrato de estágio?", categoria: "Contratos", ativo: true },
];

export function FaqPage() {
  const [data, setData] = useState(faqData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ pergunta: "", resposta: "", categoria: "Geral", ativo: true });

  const columns: Column[] = [
    { key: "pergunta", label: "Pergunta", sortable: true },
    { key: "categoria", label: "Categoria" },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const filters: FilterConfig[] = [
    { key: "pergunta", label: "Pergunta", type: "text" },
    { key: "categoria", label: "Categoria", type: "select", options: ["Geral", "Cadastros", "Contratos", "Financeiro", "Outros"].map(v => ({ label: v, value: v })) },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ pergunta: r.pergunta, resposta: r.resposta || "", categoria: r.categoria, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.pergunta) { toast.error("Preencha a pergunta."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("FAQ atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("FAQ criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "FAQ" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Perguntas Frequentes (FAQ)</h1><p className="text-sm text-muted-foreground">{data.length} perguntas cadastradas.</p></div>
          <button onClick={() => { setEditing(null); setForm({ pergunta: "", resposta: "", categoria: "Geral", ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Nova Pergunta</button>
        </div>
        <DataTable columns={columns} data={data} filters={filters} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar FAQ" : "Nova Pergunta FAQ"} onSave={save} wide>
        <div className="space-y-4">
          <div><Label>Pergunta *</Label><Input value={form.pergunta} onChange={e => setForm({ ...form, pergunta: e.target.value })} /></div>
          <div><Label>Categoria</Label>
            <Select value={form.categoria} onValueChange={v => setForm({ ...form, categoria: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{["Geral", "Cadastros", "Contratos", "Financeiro", "Outros"].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Resposta</Label><RichTextEditor value={form.resposta} onChange={v => setForm({ ...form, resposta: v })} /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir FAQ" description="Deseja excluir esta pergunta?" />
    </DashboardLayout>
  );
}

// ── 9. MOTIVOS DE ADVERTÊNCIA JA ─────────────────────────────────────────
const motivosAdvData = [
  { id: "1", descricao: "Falta injustificada", ativo: true },
  { id: "2", descricao: "Atraso recorrente", ativo: true },
  { id: "3", descricao: "Comportamento inadequado", ativo: true },
  { id: "4", descricao: "Descumprimento de normas", ativo: true },
];

export function MotivosAdvertenciaJAPage() {
  const [data, setData] = useState(motivosAdvData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ descricao: "", ativo: true });

  const columns: Column[] = [
    { key: "descricao", label: "Descrição", sortable: true },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ descricao: r.descricao, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.descricao) { toast.error("Preencha a descrição."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Motivos de Advertência JA" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Motivos de Advertência — Jovem Aprendiz</h1><p className="text-sm text-muted-foreground">{data.length} motivos cadastrados.</p></div>
          <button onClick={() => { setEditing(null); setForm({ descricao: "", ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Novo</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Motivo" : "Novo Motivo"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Descrição *</Label><Input value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir Motivo" description="Deseja excluir este motivo?" />
    </DashboardLayout>
  );
}

// ── 10. PALESTRAS ────────────────────────────────────────────────────────
const palestrasData = [
  { id: "1", titulo: "Mercado de Trabalho para Jovens", data: "2024-04-15", horario: "14:00", local: "Auditório Principal", palestrante: "Dra. Ana Lima", vagas: 50, ativo: true },
  { id: "2", titulo: "Finanças Pessoais", data: "2024-05-10", horario: "09:00", local: "Sala de Treinamento", palestrante: "Carlos Mendes", vagas: 30, ativo: true },
];

export function PalestrasPage() {
  const [data, setData] = useState(palestrasData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ titulo: "", descricao: "", data: "", horario: "", local: "", palestrante: "", vagas: 30, ativo: true });

  const columns: Column[] = [
    { key: "titulo", label: "Título", sortable: true },
    { key: "data", label: "Data" },
    { key: "horario", label: "Horário" },
    { key: "local", label: "Local" },
    { key: "palestrante", label: "Palestrante" },
    { key: "vagas", label: "Vagas" },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const filters: FilterConfig[] = [
    { key: "titulo", label: "Título", type: "text" },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ titulo: r.titulo, descricao: r.descricao || "", data: r.data, horario: r.horario, local: r.local, palestrante: r.palestrante, vagas: r.vagas, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.titulo) { toast.error("Preencha o título."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Palestra atualizada!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Palestra criada!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Palestras" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Palestras</h1><p className="text-sm text-muted-foreground">{data.length} palestras cadastradas.</p></div>
          <button onClick={() => { setEditing(null); setForm({ titulo: "", descricao: "", data: "", horario: "", local: "", palestrante: "", vagas: 30, ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Nova Palestra</button>
        </div>
        <DataTable columns={columns} data={data} filters={filters} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Palestra" : "Nova Palestra"} onSave={save} wide>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><Label>Título *</Label><Input value={form.titulo} onChange={e => setForm({ ...form, titulo: e.target.value })} /></div>
          <div><Label>Data</Label><Input type="date" value={form.data} onChange={e => setForm({ ...form, data: e.target.value })} /></div>
          <div><Label>Horário</Label><Input type="time" value={form.horario} onChange={e => setForm({ ...form, horario: e.target.value })} /></div>
          <div><Label>Local</Label><Input value={form.local} onChange={e => setForm({ ...form, local: e.target.value })} /></div>
          <div><Label>Palestrante</Label><Input value={form.palestrante} onChange={e => setForm({ ...form, palestrante: e.target.value })} /></div>
          <div><Label>Vagas</Label><Input type="number" value={form.vagas} onChange={e => setForm({ ...form, vagas: Number(e.target.value) })} /></div>
          <div className="col-span-2"><Label>Descrição</Label><Textarea value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} /></div>
          <div className="col-span-2 flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluída."); setConfirm(null); }} title="Excluir Palestra" description="Deseja excluir esta palestra?" />
    </DashboardLayout>
  );
}

// ── 11. GRUPOS DE ALERTA ─────────────────────────────────────────────────
const gruposAlertaData = [
  { id: "1", nome: "Equipe RH", membros: 3, alertas: 5 },
  { id: "2", nome: "Financeiro", membros: 2, alertas: 3 },
  { id: "3", nome: "Gestores", membros: 5, alertas: 8 },
];

export function GruposAlertaPage() {
  const [data, setData] = useState(gruposAlertaData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ nome: "" });

  const columns: Column[] = [
    { key: "nome", label: "Nome do Grupo", sortable: true },
    { key: "membros", label: "Membros" },
    { key: "alertas", label: "Alertas Associados" },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ nome: r.nome }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.nome) { toast.error("Preencha o nome."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Grupo atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form, membros: 0, alertas: 0 }]); toast.success("Grupo criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Grupos de Alerta" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Grupos de Alerta</h1><p className="text-sm text-muted-foreground">{data.length} grupos cadastrados.</p></div>
          <button onClick={() => { setEditing(null); setForm({ nome: "" }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Novo Grupo</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Grupo" : "Novo Grupo de Alerta"} onSave={save}>
        <div><Label>Nome do Grupo *</Label><Input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} /></div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluído."); setConfirm(null); }} title="Excluir Grupo" description="Deseja excluir este grupo?" />
    </DashboardLayout>
  );
}

// ── 12. PARAMETRIZAÇÃO HOTSITE ───────────────────────────────────────────
export function HotsitePage() {
  const [form, setForm] = useState({
    titulo: "Vagas — LideraRH",
    descricao: "Confira as vagas de estágio e aprendizagem disponíveis!",
    cor_primaria: "#6B46C1",
    cor_secundaria: "#42A5F5",
    conteudo: "",
  });

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Hotsite" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Parametrização Hotsite</h1><p className="text-sm text-muted-foreground">Configure o hotsite público de divulgação de vagas.</p></div>
          <Button className="gap-2" onClick={() => toast.success("Configurações salvas!")}><Save className="h-4 w-4" /> Salvar</Button>
        </div>
        <div className="rounded-xl bg-card shadow-card p-6 space-y-5">
          <div><Label>Título do Hotsite</Label><Input value={form.titulo} onChange={e => setForm({ ...form, titulo: e.target.value })} /></div>
          <div><Label>Descrição</Label><Textarea value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} rows={3} /></div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Cor Primária</Label>
              <div className="flex items-center gap-2 mt-1.5">
                <input type="color" value={form.cor_primaria} onChange={e => setForm({ ...form, cor_primaria: e.target.value })} className="h-10 w-10 rounded border border-border cursor-pointer" />
                <Input value={form.cor_primaria} onChange={e => setForm({ ...form, cor_primaria: e.target.value })} className="flex-1" />
              </div>
            </div>
            <div>
              <Label>Cor Secundária</Label>
              <div className="flex items-center gap-2 mt-1.5">
                <input type="color" value={form.cor_secundaria} onChange={e => setForm({ ...form, cor_secundaria: e.target.value })} className="h-10 w-10 rounded border border-border cursor-pointer" />
                <Input value={form.cor_secundaria} onChange={e => setForm({ ...form, cor_secundaria: e.target.value })} className="flex-1" />
              </div>
            </div>
          </div>
          <div>
            <Label>Imagem de Fundo</Label>
            <div className="border-2 border-dashed border-border rounded-xl p-8 text-center mt-1.5 hover:border-primary/50 transition-colors cursor-pointer">
              <p className="text-sm text-muted-foreground">Clique para selecionar uma imagem (PNG/JPG até 5MB)</p>
            </div>
          </div>
          <div><Label>Conteúdo Adicional</Label><RichTextEditor value={form.conteudo} onChange={v => setForm({ ...form, conteudo: v })} /></div>
        </div>
        {/* Preview */}
        <div className="rounded-xl overflow-hidden border border-border">
          <div className="px-4 py-2 bg-muted text-xs text-muted-foreground font-medium border-b border-border">Pré-visualização</div>
          <div className="p-8 text-center" style={{ background: `linear-gradient(135deg, ${form.cor_primaria}22, ${form.cor_secundaria}22)` }}>
            <h2 className="text-xl font-bold" style={{ color: form.cor_primaria }}>{form.titulo}</h2>
            <p className="text-sm text-muted-foreground mt-2">{form.descricao}</p>
            <button className="mt-4 px-6 py-2 rounded-lg text-white text-sm font-semibold" style={{ backgroundColor: form.cor_primaria }}>Ver Vagas</button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

// ── 13. MOEDAS ────────────────────────────────────────────────────────────
const moedasData = [
  { id: "1", nome: "Real Brasileiro", simbolo: "R$", codigo_iso: "BRL", principal: true, ativo: true },
  { id: "2", nome: "Dólar Americano", simbolo: "$", codigo_iso: "USD", taxa_cambio: 4.97, principal: false, ativo: true },
  { id: "3", nome: "Euro", simbolo: "€", codigo_iso: "EUR", taxa_cambio: 5.38, principal: false, ativo: false },
];

export function MoedasPage() {
  const [data, setData] = useState(moedasData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ nome: "", simbolo: "", codigo_iso: "", taxa_cambio: "", principal: false, ativo: true });

  const columns: Column[] = [
    { key: "nome", label: "Nome", sortable: true },
    { key: "simbolo", label: "Símbolo" },
    { key: "codigo_iso", label: "Código ISO" },
    { key: "taxa_cambio", label: "Taxa de Câmbio", render: v => v ? `R$ ${Number(v).toFixed(2)}` : "Principal" },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ nome: r.nome, simbolo: r.simbolo, codigo_iso: r.codigo_iso, taxa_cambio: r.taxa_cambio || "", principal: r.principal, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.nome || !form.codigo_iso) { toast.error("Preencha nome e código ISO."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Moeda atualizada!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Moeda criada!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Moedas" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Moedas</h1><p className="text-sm text-muted-foreground">{data.length} moedas cadastradas.</p></div>
          <button onClick={() => { setEditing(null); setForm({ nome: "", simbolo: "", codigo_iso: "", taxa_cambio: "", principal: false, ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Nova Moeda</button>
        </div>
        <DataTable columns={columns} data={data} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Moeda" : "Nova Moeda"} onSave={save}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Nome *</Label><Input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} /></div>
            <div><Label>Símbolo</Label><Input value={form.simbolo} onChange={e => setForm({ ...form, simbolo: e.target.value })} placeholder="R$" /></div>
            <div><Label>Código ISO *</Label><Input value={form.codigo_iso} onChange={e => setForm({ ...form, codigo_iso: e.target.value })} placeholder="BRL" /></div>
            {!form.principal && <div><Label>Taxa de Câmbio (R$)</Label><Input type="number" step="0.01" value={form.taxa_cambio} onChange={e => setForm({ ...form, taxa_cambio: e.target.value })} /></div>}
          </div>
          <div className="flex items-center gap-3"><Switch checked={form.principal} onCheckedChange={v => setForm({ ...form, principal: v })} /><Label>Moeda principal</Label></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluída."); setConfirm(null); }} title="Excluir Moeda" description="Deseja excluir esta moeda?" />
    </DashboardLayout>
  );
}

// ── 14. INSTITUIÇÃO FINANCEIRA ────────────────────────────────────────────
const instFinData = [
  { id: "1", nome: "Banco do Brasil", codigo: "001", ativo: true },
  { id: "2", nome: "Caixa Econômica Federal", codigo: "104", ativo: true },
  { id: "3", nome: "Bradesco", codigo: "237", ativo: true },
  { id: "4", nome: "Itaú Unibanco", codigo: "341", ativo: true },
  { id: "5", nome: "Santander", codigo: "033", ativo: true },
  { id: "6", nome: "Nubank", codigo: "260", ativo: true },
];

export function InstituicaoFinanceiraPage() {
  const [data, setData] = useState(instFinData);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [confirm, setConfirm] = useState<any>(null);
  const [form, setForm] = useState({ nome: "", codigo: "", ativo: true });

  const columns: Column[] = [
    { key: "codigo", label: "Código" },
    { key: "nome", label: "Nome", sortable: true },
    { key: "ativo", label: "Status", render: statusBadge },
  ];
  const filters: FilterConfig[] = [{ key: "nome", label: "Nome", type: "text" }];
  const actions: ActionConfig[] = [
    { label: "Editar", onClick: (r) => { setEditing(r); setForm({ nome: r.nome, codigo: r.codigo, ativo: r.ativo }); setModal(true); } },
    { label: "Excluir", variant: "destructive", onClick: (r) => setConfirm(r) },
  ];
  const save = () => {
    if (!form.nome) { toast.error("Preencha o nome."); return; }
    if (editing) { setData(data.map(d => d.id === editing.id ? { ...d, ...form } : d)); toast.success("Atualizado!"); }
    else { setData([...data, { id: String(Date.now()), ...form }]); toast.success("Criado!"); }
    setModal(false); setEditing(null);
  };

  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }, { label: "Instituições Financeiras" }]}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold text-foreground">Instituições Financeiras</h1><p className="text-sm text-muted-foreground">{data.length} instituições cadastradas.</p></div>
          <button onClick={() => { setEditing(null); setForm({ nome: "", codigo: "", ativo: true }); setModal(true); }} className="h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors inline-flex items-center gap-2"><Plus className="h-4 w-4" />Nova</button>
        </div>
        <DataTable columns={columns} data={data} filters={filters} actions={actions} />
      </div>
      <FormModal open={modal} onClose={() => { setModal(false); setEditing(null); }} title={editing ? "Editar Instituição" : "Nova Instituição Financeira"} onSave={save}>
        <div className="space-y-4">
          <div><Label>Nome *</Label><Input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} /></div>
          <div><Label>Código do Banco</Label><Input value={form.codigo} onChange={e => setForm({ ...form, codigo: e.target.value })} placeholder="001" /></div>
          <div className="flex items-center gap-3"><Switch checked={form.ativo} onCheckedChange={v => setForm({ ...form, ativo: v })} /><Label>Ativo</Label></div>
        </div>
      </FormModal>
      <ConfirmDialog open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => { setData(data.filter(d => d.id !== confirm.id)); toast.success("Excluída."); setConfirm(null); }} title="Excluir Instituição" description="Deseja excluir esta instituição?" />
    </DashboardLayout>
  );
}
