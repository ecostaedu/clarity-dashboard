import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useNavigate } from "react-router-dom";
import {
  Bell, Shield, Palette, Globe, GraduationCap, Building2,
  Coins, XCircle, Award, Hash, Tag, AlertTriangle,
  Megaphone, Users, MapPin, HelpCircle, Layers, Landmark,
} from "lucide-react";

const CONFIG_MODULES = [
  {
    section: "Sistema",
    items: [
      { title: "Personalização", desc: "Logo, cores, identidade visual", icon: Palette, route: "/settings/system" },
      { title: "Idiomas", desc: "Idiomas disponíveis no sistema", icon: Globe, route: "/configuracoes/idiomas" },
      { title: "Moedas", desc: "Moedas e taxas de câmbio", icon: Coins, route: "/configuracoes/moedas" },
      { title: "Unidades de Negócio", desc: "Filiais e unidades da empresa", icon: Building2, route: "/configuracoes/unidades-negocio" },
    ],
  },
  {
    section: "Alertas e Notificações",
    items: [
      { title: "Parametrização de Alertas", desc: "Configure notificações e avisos", icon: Bell, route: "/settings/alerts" },
      { title: "Grupos de Alerta", desc: "Grupos de usuários para alertas", icon: Users, route: "/configuracoes/grupos-alerta" },
    ],
  },
  {
    section: "Acesso e Segurança",
    items: [
      { title: "Perfis e Permissões", desc: "Grupos de acesso ao sistema", icon: Shield, route: "/settings/roles" },
    ],
  },
  {
    section: "Cadastros Auxiliares",
    items: [
      { title: "Grau de Instrução", desc: "Níveis de escolaridade", icon: GraduationCap, route: "/configuracoes/grau-instrucao" },
      { title: "Nível de Estágio", desc: "Níveis disponíveis para estágio", icon: Layers, route: "/configuracoes/nivel-estagio" },
      { title: "Setores de Vaga", desc: "Setores para classificar vagas", icon: MapPin, route: "/configuracoes/setores-vaga" },
      { title: "Motivos de Encerramento", desc: "Motivos para encerrar contratos", icon: XCircle, route: "/configuracoes/motivos-encerramento" },
      { title: "Motivos de Advertência JA", desc: "Motivos para advertências JA", icon: AlertTriangle, route: "/configuracoes/motivos-advertencia-ja" },
      { title: "Instituições Financeiras", desc: "Bancos e cooperativas", icon: Landmark, route: "/configuracoes/instituicao-financeira" },
    ],
  },
  {
    section: "Conteúdo e Engajamento",
    items: [
      { title: "Tags do Sistema", desc: "Etiquetas para classificação", icon: Tag, route: "/configuracoes/tags" },
      { title: "Perguntas FAQ", desc: "Base de perguntas frequentes", icon: HelpCircle, route: "/configuracoes/faq" },
      { title: "Palestras", desc: "Eventos e palestras programadas", icon: Megaphone, route: "/configuracoes/palestras" },
      { title: "Parametrização Hotsite", desc: "Configure o hotsite de vagas", icon: Globe, route: "/configuracoes/hotsite" },
    ],
  },
];

export default function ConfiguracoesIndex() {
  const navigate = useNavigate();
  return (
    <DashboardLayout breadcrumbs={[{ label: "Home" }, { label: "Configurações" }]}>
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Configurações</h1>
          <p className="text-sm text-muted-foreground mt-1">Gerencie todas as configurações do sistema LideraRH.</p>
        </div>
        {CONFIG_MODULES.map((group) => (
          <div key={group.section}>
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-1">{group.section}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {group.items.map((item) => (
                <button key={item.title} onClick={() => navigate(item.route)}
                  className="p-4 rounded-xl bg-card shadow-card hover:shadow-card-hover transition-all duration-150 text-left group border border-border/50 hover:border-primary/30">
                  <div className="flex items-start gap-3">
                    <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors shrink-0 mt-0.5">
                      <item.icon className="h-4 w-4 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-foreground leading-tight">{item.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{item.desc}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </DashboardLayout>
  );
}
