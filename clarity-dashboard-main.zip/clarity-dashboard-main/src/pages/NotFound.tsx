import { useNavigate } from "react-router-dom";
import { Home, ArrowLeft, Search } from "lucide-react";

const QUICK_LINKS = [
  { label: "Dashboard", path: "/home" },
  { label: "Empresas Parceiras", path: "/cadastros/empresas" },
  { label: "Processos Seletivos", path: "/recrutamento/processos" },
  { label: "Contratos de Estágio", path: "/contratos/estagio" },
  { label: "Financeiro", path: "/financeiro" },
  { label: "Configurações", path: "/configuracoes" },
];

const NotFound = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-8">
      <div className="max-w-lg w-full text-center">
        <div className="relative mb-8 select-none">
          <span className="text-[140px] font-black leading-none tracking-tighter"
            style={{ background: "linear-gradient(135deg, hsl(259,50%,52%) 0%, hsl(199,89%,48%) 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
            404
          </span>
        </div>
        <div className="mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 mb-4">
            <Search className="h-6 w-6 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Página não encontrada</h1>
          <p className="text-muted-foreground text-sm leading-relaxed max-w-xs mx-auto">
            A página que você está procurando não existe ou foi movida para outro endereço.
          </p>
        </div>
        <div className="flex items-center justify-center gap-3 mb-10">
          <button onClick={() => navigate(-1)} className="inline-flex items-center gap-2 h-10 px-5 rounded-xl border border-border bg-card text-sm font-medium text-foreground hover:bg-muted transition-colors">
            <ArrowLeft className="h-4 w-4" /> Voltar
          </button>
          <button onClick={() => navigate("/home")} className="inline-flex items-center gap-2 h-10 px-5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
            <Home className="h-4 w-4" /> Ir para o início
          </button>
        </div>
        <div className="rounded-xl bg-card border border-border p-5">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">Acesso rápido</p>
          <div className="grid grid-cols-2 gap-2">
            {QUICK_LINKS.map((link) => (
              <button key={link.path} onClick={() => navigate(link.path)} className="text-left px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-primary hover:bg-primary/5 transition-all font-medium">
                {link.label}
              </button>
            ))}
          </div>
        </div>
        <p className="mt-6 text-xs text-muted-foreground/60">LideraRH · Se o problema persistir, entre em contato com o suporte</p>
      </div>
    </div>
  );
};
export default NotFound;
